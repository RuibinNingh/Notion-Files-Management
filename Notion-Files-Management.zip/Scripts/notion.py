import requests
import time
from datetime import datetime, timezone
from logger import PythonLogger

class Notion:
    def __init__(self, token, version="2025-09-03", url="https://api.notion.com/v1"):
        self.token = token
        self.version = version
        self.url = url
        if(self.url[-1] == '/'):
            self.url = self.url[:-1]
        self.default_headers = {#默认请求头模板
            "Notion-Version": self.version,
            "Authorization": f"Bearer {self.token}",
        }
    def query_page(self, page_id, fetch_all=False):
        all_blocks = []
        cursor = None#分页游标
        max_retries = 4 # 最大重试次数
        while True:
            # 1. 处理分页请求
            params = {"start_cursor": cursor} if cursor else {}#只有在有游标时才添加该参数
            #======请求重试机制=======
            for attempt in range(max_retries):
                try:
                    res = requests.get(
                        f"{self.url}/blocks/{page_id}/children", 
                        headers=self.default_headers,
                        params=params,
                        timeout=10 # 防止请求死锁
                    )
                    
                    # 如果是 429 (Too Many Requests) 或 5xx 错误，触发重试
                    if res.status_code in [429, 500, 502, 503, 504]:
                        wait_time = 2 ** attempt # 1, 2, 4, 8...
                        PythonLogger.warning(f"触发限制({res.status_code})，第 {attempt+1} 次重试，等待 {wait_time}s...")
                        time.sleep(wait_time)
                        continue
                    
                    # 成功请求，跳出重试循环
                    res.raise_for_status() 
                    break
                    
                except (requests.exceptions.RequestException, Exception) as e:
                    wait_time = 2 ** attempt
                    if attempt < max_retries - 1:
                        PythonLogger.warning(f"请求异常: {e}，等待 {wait_time}s 后重试...")
                        time.sleep(wait_time)
                    else:
                        PythonLogger.error(f"已达到最大重试次数，任务失败: {e}")
                        return all_blocks # 返回已拿到的部分数据
            #======请求重试机制=======
            data = res.json()
            blocks = data.get("results", [])
            # 2. 如果开启了 fetch_all，处理递归嵌套
            if fetch_all:
                for block in blocks:
                    # 检查该块是否包含子块
                    if block.get("has_children"):
                        # 递归调用自身，获取该 block 的子内容
                        # 将结果存入 block 字典中，方便前端或后续逻辑解析
                        block["children"] = self.query_page(block["id"], fetch_all=True)
            all_blocks.extend(blocks)
            # 3. 检查是否还有更多分页
            if not data.get("has_more"):
                break
            cursor = data.get("next_cursor")
        return all_blocks

    def get_download_url(self, body):
        """
        下载链接的格式:
        [
            {
                "name": "example.zip.txt"
                "real_name": "example.zip"
                "url": "https://s3.us-west-2.amazonaws.com/secure.notion-static.com/...."
                "expiry_time": "2024-10-01T12:00:00.000Z",
                "size_mb": 2.5,
                "block_id": "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx",
                "created_time": "2026-02-18T12:00:00.000Z"
            }
        ]
        """
        download_list = []
        if not body:
            return download_list

        # 记录链接创建时间（即本次获取列表的时间）
        created_time = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.000Z")

        for block in body:
            if block.get("type") == "file":
                file_info = block["file"]
                original_name = file_info.get("name", "unknown")
                block_id = block.get("id", "")

                if file_info["type"] == "file":
                    url = file_info["file"]["url"]
                    expiry_time = file_info["file"].get("expiry_time")
                else:
                    url = file_info["external"]["url"]
                    expiry_time = None

                size_mb = self._get_remote_file_size(url)

                captions = file_info.get("caption", [])
                caption_text = "".join([t.get("plain_text", "") for t in captions]).strip()
                real_name = caption_text if caption_text else original_name

                download_list.append({
                    "name": original_name,
                    "real_name": real_name,
                    "url": url,
                    "expiry_time": expiry_time,
                    "size_mb": size_mb,
                    "block_id": block_id,
                    "created_time": created_time,
                })

            if block.get("has_children") and "children" in block:
                child_downloads = self.get_download_url(block["children"])
                download_list.extend(child_downloads)

        return download_list

    def refresh_file_url(self, block_id: str) -> dict | None:
        """
        通过 block_id 重新获取单个文件块的最新下载链接。
        用于下载过程中链接过期时自动刷新。
        
        返回: {"url": "...", "expiry_time": "..."} 或 None（失败时）
        """
        max_retries = 3
        for attempt in range(max_retries):
            try:
                res = requests.get(
                    f"{self.url}/blocks/{block_id}",
                    headers=self.default_headers,
                    timeout=10
                )

                if res.status_code in [429, 500, 502, 503, 504]:
                    wait_time = 2 ** attempt
                    PythonLogger.warning(f"[refresh_file_url] 触发限制({res.status_code})，第 {attempt+1} 次重试，等待 {wait_time}s...")
                    time.sleep(wait_time)
                    continue

                res.raise_for_status()
                block = res.json()

                if block.get("type") != "file":
                    PythonLogger.warning(f"[refresh_file_url] block {block_id} type={block.get('type')}，不是 file 类型")
                    return None

                file_info = block["file"]
                if file_info["type"] == "file":
                    new_url = file_info["file"]["url"]
                    new_expiry = file_info["file"].get("expiry_time")
                else:
                    # external 类型没有过期问题
                    new_url = file_info["external"]["url"]
                    new_expiry = None

                PythonLogger.info(f"[refresh_file_url] block_id={block_id} 刷新成功，new_expiry={new_expiry}")
                return {
                    "url": new_url,
                    "expiry_time": new_expiry,
                }

            except Exception as e:
                if attempt < max_retries - 1:
                    wait_time = 2 ** attempt
                    PythonLogger.warning(f"[refresh_file_url] 异常: {e}，等待 {wait_time}s 后重试...")
                    time.sleep(wait_time)
                else:
                    PythonLogger.error(f"[refresh_file_url] block_id={block_id} 刷新失败: {e}")
                    return None

        return None

    def _get_remote_file_size(self, url):
        """探测远程文件大小，返回 MB"""
        try:
            # 使用 stream=True 或 head 请求来避免下载文件体
            response = requests.head(url, allow_redirects=True, timeout=5)
            size_bytes = response.headers.get('content-length')
            if size_bytes:
                return round(int(size_bytes) / (1024 * 1024), 2)
        except Exception as e:
            PythonLogger.warning(f"获取文件大小失败: {e}")
        return 0
        
        
if __name__ == "__main__":
    notion = Notion("your_integration_token_here")
    page_data = notion.query_page("your_page_id",True)
    download_urls = notion.get_download_url(page_data)
    print(download_urls)
