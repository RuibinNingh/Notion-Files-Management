# Notion Files Management — 项目维护指导文档

> **最后更新**: 2026年2月18日  
> **程序版本**: v1.2.0-Beta（来源：Notion-Files-Management.csproj 的 InformationalVersion）  
> **文档版本**: v1.2.0-Beta.7（程序版本.文档修订号）  
> **维护者**: [Your Team Name]

---

## 版本命名规则说明

从 v1.0.2-Beta 开始，采用新的统一版本命名规则：

**格式**: `版本.修订版本`
- `版本`: 程序版本（如 1.0.3-Beta）
- `.修订版本`: 同一程序版本下的文档修订号（从1开始）

**示例**：
- `v.1.0.3-Beta.1` - 程序版本 1.0.3-Beta，第1次文档
- `v.1.0.3-Beta.2` - 程序版本 1.0.3-Beta，第2次文档修订（程序代码不变）
- `v.1.0.4-Beta.1` - 程序版本 1.0.4-Beta，第1次文档

---

## 目录

1. [项目概述](#1-项目概述)
2. [技术栈与架构](#2-技术栈与架构)
3. [环境配置与运行](#3-环境配置与运行)
4. [项目结构详解](#4-项目结构详解)
5. [核心业务流程](#5-核心业务流程)
6. [会话状态管理](#6-会话状态管理)
7. [日志与调试](#7-日志与调试)
8. [常见问题与Bug修复记录](#8-常见问题与bug修复记录)
9. [开发规范与最佳实践](#9-开发规范与最佳实践)
10. [部署与发布](#10-部署与发布)

---

## 1. 项目概述

### 1.1 项目简介

Notion Files Management 是一个基于 WPF 的桌面应用程序，用于批量管理 Notion 页面中的文件（下载、上传）。

**主要功能**：
- 📥 **批量下载**：获取 Notion 页面文件列表，探测文件大小，选择性下载
- 📤 **批量上传**：将本地文件批量上传到指定 Notion 页面
- 🔧 **工具箱**：查看 Notion 页面文件信息统计、查看应用日志文件
- ⚙️ **设置管理**：配置 Notion Token、API 地址、并发数等
- 🎨 **主题色设置**：自定义应用主题色，支持 HSV/RGB 颜色空间选择（v1.1.0-Beta+）
- 🖼️ **背景材质设置**：选择窗口背景材质（云母/亚克力/图片），支持亚克力不透明度调节（v1.1.0-Beta+），支持自定义图片/视频背景及模糊度和不透明度调节（v1.2.0-Beta+）

### 1.2 设计理念

- **前后端分离**：WPF 前端（C#）+ Python 后端（通过 pythonnet 调用）
- **会话持久化**：页面切换时保留任务状态，避免任务丢失
- **异步轮询**：通过定时器轮询后端状态，保持 UI 响应
- **GIL 安全**：所有 Python 调用通过 `PythonBackendHost` 串行化，避免 GIL 相关问题

---

## 2. 技术栈与架构

### 2.1 技术栈

| 层次 | 技术 | 版本 | 用途 |
|------|------|------|------|
| **前端框架** | WPF | .NET 8.0 | UI 框架 |
| **UI 库** | WPF-UI | 4.2.0 | 现代化 UI 组件 |
| **Python 调用** | pythonnet | 3.0.5 | C# 调用 Python 代码 |
| **Python 运行时** | Python | 3.11 | 内嵌 Python 环境 |
| **后端逻辑** | Python | 3.11+ | 文件下载/上传逻辑 |

### 2.2 架构图

```
┌─────────────────────────────────────────────────────────┐
│                      WPF 前端 (C#)                      │
├─────────────────────────────────────────────────────────┤
│  Views/              Services/           Models/        │
│  ├─ DownloadPage     ├─ PythonBackendHost              │
│  ├─ UploadPage       ├─ NotionBackendService            │
│  ├─ ToolsPage        ├─ DownloadSession (单例)          │
│  └─ SettingsPage     └─ UploadSession (单例)            │
├─────────────────────────────────────────────────────────┤
│              pythonnet (C# ↔ Python 桥接)              │
├─────────────────────────────────────────────────────────┤
│                   Python 后端 (Scripts/)                │
│  ├─ main.py          ─ Main 类（统一入口）             │
│  ├─ notion.py        ─ Notion API 调用                 │
│  ├─ download.py      ─ 多线程下载逻辑                   │
│  └─ upload.py        ─ 多线程上传逻辑（分片、限流）       │
└─────────────────────────────────────────────────────────┘
```

### 2.3 关键设计模式

- **单例模式**：`DownloadSession`, `UploadSession`, `NotionBackendService`
- **门面模式**：`NotionBackendService` 封装 Python 调用细节
- **观察者模式**：`TaskResetNotifier` 通知各页面重置任务
- **MVVM 模式**（部分）：Models 使用 `INotifyPropertyChanged` 实现数据绑定

---

## 3. 环境配置与运行

### 3.1 开发环境要求

- **操作系统**：Windows 10/11 (x64)
- **开发工具**：Visual Studio 2022 (推荐) 或 Rider
- **.NET SDK**：.NET 8.0 SDK
- **Python 运行时**：Python 3.11 (x64) — 程序内嵌，无需系统安装

### 3.2 Python 运行时配置

**关键文件**：`PythonEnv/python311.dll`

- **必须存在**：`<程序目录>/PythonEnv/python311.dll`
- **架构匹配**：必须是 x64 版本（如果程序编译为 x64）
- **初始化位置**：`App.xaml.cs`

```csharp
Runtime.PythonDLL = Path.Combine(appDir, "PythonEnv", "python311.dll");
PythonEngine.Initialize();
PythonEngine.BeginAllowThreads();
```

### 3.3 用户配置文件

**路径**：`%AppData%\NotionFilesManagement\config.json`

```json
{
  "NotionToken": "secret_xxx",
  "NotionBaseUrl": "https://api.notion.com/v1",
  "MaxDownloadWorkers": 3,
  "MaxUploadWorkers": 3,
  "ThemeAccentColor": "#1E90FF",
  "BackgroundMaterial": "Mica",
  "AcrylicOpacity": 0.8,
  "BackgroundImagePath": "",
  "BackgroundImageBlur": 0,
  "BackgroundImageOpacity": 0.3
}
```

**字段说明**：
- `NotionToken`: Notion Integration Token
- `NotionBaseUrl`: Notion API 基础地址（默认：`https://api.notion.com/v1`）
- `MaxDownloadWorkers`: 下载并发数（1-16）
- `MaxUploadWorkers`: 上传并发数（1-16）
- `ThemeAccentColor`: 主题色（格式：`#RRGGBB`，默认：`#1E90FF`，v1.1.0-Beta+）
- `BackgroundMaterial`: 背景材质类型（可选值：`"Mica"`（云母）、`"Acrylic"`（亚克力）或 `"Image"`（图片/视频），默认：`"Mica"`，v1.1.0-Beta+，v1.2.0-Beta+ 新增 Image）
- `AcrylicOpacity`: 亚克力材质不透明度（范围：0.0-1.0，默认：0.8，仅在 `BackgroundMaterial` 为 `"Acrylic"` 时生效，v1.1.0-Beta+）
- `BackgroundImagePath`: 背景图片/视频绝对路径（仅在 `BackgroundMaterial` 为 `"Image"` 时生效，支持 .png/.jpg/.jpeg/.bmp/.gif/.mp4，v1.2.0-Beta+）
- `BackgroundImageBlur`: 背景模糊度（范围：0-50 像素，默认：0，仅在 `BackgroundMaterial` 为 `"Image"` 时生效，v1.2.0-Beta+）
- `BackgroundImageOpacity`: 背景不透明度（范围：0.0-1.0，默认：0.3，仅在 `BackgroundMaterial` 为 `"Image"` 时生效，v1.2.0-Beta+）

**管理类**：`AppConfig.cs → ConfigManager`

### 3.4 本地运行步骤

1. **克隆仓库**
   ```bash
   git clone <repo-url>
   cd Notion-Files-Management
   ```

2. **打开解决方案**
   ```bash
   start Notion-Files-Management.sln
   ```

3. **确保 Python 环境存在**
   - 检查 `PythonEnv/python311.dll` 是否存在
   - 如需重新构建 Python 环境，参考 [部署与发布](#10-部署与发布)

4. **运行项目**
   - 按 F5 或点击 Visual Studio 的"开始调试"

5. **首次配置**
   - 点击左侧"设置"菜单
   - 填写 Notion Token（从 [Notion Integrations](https://www.notion.so/my-integrations) 获取）
   - 点击"应用设置"

---

## 4. 项目结构详解

### 4.1 整体目录结构

```
Notion-Files-Management/
├─ App.xaml.cs                  # 应用启动：初始化 pythonnet、日志、sys.path
├─ MainWindow.xaml(.cs)         # WpfUI 的 Navigation 容器
├─ AppConfig.cs                 # ConfigManager：读写用户配置
├─ icon.ico / icon.png          # 程序图标
│
├─ PythonEnv/                   # 内嵌 Python 3.11 运行时
│  ├─ python311.dll             # ⚠️ 必须存在，否则无法启动
│  └─ ...                       # Python 标准库和依赖
│
├─ Scripts/                     # Python 后端代码
│  ├─ main.py                   # Main 类（前端调用的统一入口）
│  ├─ notion.py                 # Notion API 封装（查询页面、获取下载链接）
│  ├─ download.py               # Download 类（多线程下载、size 探测）
│  ├─ upload.py                 # Upload 类（分片上传、限流、队列管理）
│  ├─ logger.py                 # Python 日志模块（统一日志管理）
│  └─ toolkit.py                # 工具函数（预留）
│
├─ Services/                    # 业务服务层
│  ├─ PythonBackendHost.cs      # pythonnet 调用封装（GIL 安全、_pyLock）
│  ├─ NotionBackendService.cs   # ⭐ 前端调用 Python 的门面服务
│  ├─ DownloadSession.cs        # ⭐ 下载页会话状态（单例）
│  ├─ UploadSession.cs          # ⭐ 上传页会话状态（单例）
│  └─ TaskResetNotifier.cs      # 设置页"重置任务"时通知各页面
│
├─ Models/                      # 数据模型
│  ├─ ObservableObject.cs       # INotifyPropertyChanged 基类
│  ├─ FileSelectItem.cs         # 下载对话框文件项（snake_case 字段）
│  ├─ DownloadTaskStatus.cs     # 下载任务状态（UI 模型）
│  ├─ UploadTaskStatus.cs       # 上传任务状态（UI 模型）
│  ├─ UploadStatusDto.cs        # 上传状态 DTO（Python 原始字段）
│  └─ PageInfoItem.cs           # 工具箱"页面信息"列表项
│
├─ Views/                       # 页面视图
│  ├─ DownloadPage.xaml(.cs)    # 下载页：获取列表 → 探测大小 → 选择 → 下载 + 轮询
│  ├─ UploadPage.xaml(.cs)      # 上传页：选择文件 → 创建任务 + 轮询状态
│  ├─ ToolsPage.xaml(.cs)       # 工具箱：页面文件信息（仅探测/统计）
│  ├─ SettingsPage.xaml(.cs)    # 设置：Token/BaseUrl/并发，主题色设置，背景材质设置（含图片/视频背景，v1.2.0-Beta+），应用并重置，检查版本更新（贪心高度平衡自动排版，v1.2.0-Beta.2+）
│  ├─ DashboardPage.xaml(.cs)   # 仪表板（预留）
│  ├─ Controls/                 # 自定义控件（v1.1.0-Beta+）
│  │  └─ InlineColorPicker.xaml(.cs)  # 嵌入式颜色选择器控件
│
├─ Utils/                       # 工具类
│  ├─ Logger.cs                 # 日志工具（文件日志）
│  ├─ PyConvert.cs              # Python 类型转换辅助
│  ├─ PythonHelpers.cs          # Python 对象访问辅助
│  ├─ UiHelpers.cs              # UI 辅助函数
│  └─ ResponsiveClampConverter.cs  # XAML 值转换器
│
└─ logs/                        # 运行时日志目录（自动创建）
   ├─ yyyyMMddHHmmss-C#.logs    # C# 日志文件
   └─ yyyyMMddHHmmss-Py.logs    # Python 日志文件（v1.0.3-Beta.2+）
```

### 4.2 关键文件说明

#### 4.2.1 App.xaml.cs（应用入口）

**职责**：
1. 应用深色主题
2. 应用主题色配置（v1.1.0-Beta+）
3. 初始化 pythonnet 运行时
4. 设置 `sys.path` 使 Python 能找到 `Scripts/` 目录
5. 初始化日志系统

**注意**：背景材质配置在 `MainWindow.xaml.cs` 的 `Loaded` 事件中应用（v1.1.0-Beta+），图片/视频背景通过自定义图层实现（v1.2.0-Beta+）

**关键代码**：
```csharp
protected override void OnStartup(StartupEventArgs e)
{
    base.OnStartup(e);
    
    // 1. 应用深色主题
    ApplicationThemeManager.Apply(ApplicationTheme.Dark);
    
    // 2. 应用主题色配置（v1.1.0-Beta+）
    ConfigManager.Load();
    string themeColorHex = ConfigManager.Current?.ThemeAccentColor ?? ConfigData.DefaultThemeAccentColor;
    if (!themeColorHex.StartsWith("#"))
        themeColorHex = "#" + themeColorHex;
    
    var accentColor = (Color)ColorConverter.ConvertFromString(themeColorHex);
    ApplicationAccentColorManager.Apply(
        systemAccent: accentColor,
        primaryAccent: accentColor,
        secondaryAccent: accentColor,
        tertiaryAccent: accentColor
    );
    
    // 3. 初始化日志系统
    Logger.InitFileLogging();
    
    // 4. 初始化 pythonnet 运行时
    var appDir = AppDomain.CurrentDomain.BaseDirectory;
    Runtime.PythonDLL = Path.Combine(appDir, "PythonEnv", "python311.dll");
    PythonEngine.Initialize();
    PythonEngine.BeginAllowThreads();
    
    // 5. 添加 Scripts 到 sys.path
    using (Py.GIL())
    {
        dynamic sys = Py.Import("sys");
        sys.path.append(Path.Combine(appDir, "Scripts"));
    }
}
```

#### 4.2.2 NotionBackendService.cs（门面服务）

**职责**：
- 封装所有 Python 调用逻辑
- 提供高层 API 给页面使用
- 处理类型转换（Python ↔ C#）
- 统一异常处理

**核心方法**：
| 方法 | 功能 | 返回值 |
|------|------|--------|
| `EnsureBackendReadyFromConfigAsync()` | 从配置初始化 Python Main 实例 | `(bool ok, string err)` |
| `FetchDownloadListWithProbeAsync(pageId, progress, token)` | 获取下载列表并探测文件大小 | `(int ProbeId, List<FileSelectItem>, ...)` |
| `StartDownloadAsync(files, saveDir)` | 启动批量下载任务 | `string` |
| `GetDownloadStatusesAsync()` | 获取所有下载任务状态 | `List<DownloadTaskStatus>` |
| `StartUploadAsync(pageId, filePaths)` | 启动批量上传任务 | `string` |
| `GetUploadStatusesAsync()` | 获取所有上传任务状态 | `List<UploadStatusDto>` |

#### 4.2.3 PythonBackendHost.cs（GIL 安全层）

**职责**：
- 确保同一时间只有一个线程进入 Python（`SemaphoreSlim _pyLock`）
- 每次调用都包裹 `Py.GIL()`
- 持有 `main.Main` 实例

**关键代码**：
```csharp
public async Task<T> RunPython<T>(Func<T> action)
{
    await _pyLock.WaitAsync();
    try
    {
        using (Py.GIL())
        {
            return action();
        }
    }
    finally
    {
        _pyLock.Release();
    }
}
```

#### 4.2.4 DownloadSession.cs / UploadSession.cs（会话状态）

**职责**：
- **单例模式**：全局唯一实例
- **持久化状态**：保存页面切换后的任务列表、配置参数
- **恢复状态**：页面 `Loaded` 时根据会话状态恢复轮询

**DownloadSession 字段**：
```csharp
public ObservableCollection<FileSelectItem> FileSelectionList { get; }  // 文件选择列表
public ObservableCollection<DownloadTaskStatus> DisplayTasks { get; }   // 下载任务列表
public string SaveDirectory { get; set; }                               // 保存目录
public string PageId { get; set; }                                      // 页面 ID
public bool HasActiveDownloads { get; set; }                            // 是否有活跃下载
```

**UploadSession 字段**：
```csharp
public ObservableCollection<UploadTaskStatus> DisplayUploads { get; }   // 上传任务列表
public ObservableCollection<string> SelectedUploadFiles { get; }        // 已选文件列表
public Dictionary<string, double> SpeedEma { get; }                     // EMA 速度平滑字典
public string PageId { get; set; }                                      // 页面 ID
public bool HasActiveUploads { get; set; }                              // 是否有活跃上传
```

---

## 5. 核心业务流程

### 5.1 下载流程

```
用户操作                    前端（C#）                     后端（Python）
    │                           │                              │
    ├─ 输入 Page ID             │                              │
    │                           │                              │
    ├─ 点击"获取列表"            │                              │
    │                           ├─ NotionBackendService         │
    │                           │  .FetchDownloadListWith       │
    │                           │   ProbeAsync()               │
    │                           │                              │
    │                           ├─────────────────────────────►│
    │                           │  main.get_download_list()   │
    │                           │                              ├─ Notion API
    │                           │                              │  查询页面
    │                           │                              │
    │                           │◄─────────────────────────────┤
    │                           │  返回: probe_id, total       │
    │                           │                              │
    │                           ├─ 轮询探测进度                 │
    │                           │                              │
    │                           ├─────────────────────────────►│
    │                           │  main.download_list_         │
    │◄──────────────────────────┤   processing(probe_id)       │
    │  显示进度：                │                              ├─ 多线程 HEAD
    │  "探测中 50% (5/10)"        │◄─────────────────────────────┤  请求探测
    │                           │  返回: status, percent,      │  文件大小
    │                           │         done, total          │
    │                           │                              │
    │                           ├─ 直到 status = "done"        │
    │                           │                              │
    │                           ├─ 读取 main.download_list     │
    │                           │  (已填充 size_mb)            │
    │◄──────────────────────────┤                              │
    │  显示文件列表（带大小）       │                              │
    │                           │                              │
    ├─ 选择文件                   │                              │
    ├─ 选择保存目录                │                              │
    ├─ 点击"开始下载"              │                              │
    │                           ├─ NotionBackendService        │
    │                           │  .StartDownloadAsync()       │
    │                           │                              │
    │                           ├─────────────────────────────►│
    │                           │  main.download_notion_files()│
    │                           │                              ├─ 创建下载任务
    │                           │◄─────────────────────────────┤  (进入队列)
    │                           │  返回: "Download tasks        │
    │                           │          started"            │
    │                           │                              │
    │                           ├─ 启动轮询定时器（1秒/次）       │
    │                           │                              │
    │                           ├─────────────────────────────►│
    │◄──────────────────────────┤  main.get_download_statuses()│
    │  更新任务列表：              │◄─────────────────────────────┤
    │  文件A: downloading 30%   │  返回: [{url, status,        │
    │  文件B: waiting 0%         │          progress, ...}]     │
    │                           │                              │
    │                           ├─ 持续轮询直到                 │
    │                           │  所有任务 completed/error     │
    │                           │                              │
    └───────────────────────────┴──────────────────────────────┴─
```

**关键步骤**：
1. **获取列表**：调用 `main.get_download_list(page_id)` → 返回 `probe_id`
2. **轮询探测**：调用 `main.download_list_processing(probe_id)` 直到 `status=done`
3. **显示列表**：读取 `main.download_list`，转换为 `FileSelectItem` 列表（含 `block_id`、`created_time`）
4. **开始下载**：调用 `main.download_notion_files(files, save_dir)`，后端为每个有 `block_id` 的文件注册 URL 刷新回调
5. **轮询状态**：每秒调用 `main.get_download_statuses()`，更新 UI（状态含 `created_time`）
6. **链接过期自动刷新**：下载遇到 HTTP 401/403/410 时，后端通过 `block_id` 调用 `Notion.refresh_file_url()` 获取新 URL 并重试（最多 2 次），期间状态为 `"refreshing"`

### 5.2 上传流程

```
用户操作                    前端（C#）                     后端（Python）
    │                           │                              │
    ├─ 选择本地文件               │                              │
    ├─ 输入 Page ID             │                              │
    │                           │                              │
    ├─ 点击"开始上传"              │                              │
    │                           ├─ NotionBackendService        │
    │                           │  .StartUploadAsync()         │
    │                           │                              │
    │                           ├─────────────────────────────►│
    │                           │  main.upload_notion_files()  │
    │                           │                              ├─ 创建上传任务
    │                           │◄─────────────────────────────┤  (进入队列)
    │                           │  返回: "Success"             │
    │                           │                              │
    │                           ├─ 立即添加任务到 UI            │
    │◄──────────────────────────┤  (状态: waiting)              │
    │  显示任务列表                │                              │
    │                           │                              │
    │                           ├─ 启动轮询定时器（1秒/次）       │
    │                           │                              │
    │                           ├─────────────────────────────►│
    │◄──────────────────────────┤  main.get_upload_statuses()  │
    │  更新任务列表：              │◄─────────────────────────────┤
    │  文件A: uploading 50%     │  返回: [{file_path, status,  │
    │  文件B: waiting 0%         │          stage, progress,    │
    │                           │          speed_mb_s, ...}]   │
    │                           │                              │
    │                           ├─ EMA 平滑速度显示             │
    │                           │  (α=0.2)                     │
    │                           │                              │
    │                           ├─ 持续轮询直到                 │
    │                           │  所有任务 completed/error     │
    │                           │                              │
    └───────────────────────────┴──────────────────────────────┴─
```

**关键步骤**：
1. **创建任务**：调用 `main.upload_notion_files(page_id, file_paths)`
2. **立即显示**：在 UI 添加任务（状态 `waiting`），避免首次轮询前的空白
3. **轮询状态**：每秒调用 `main.get_upload_statuses()`
4. **EMA 平滑**：速度显示采用指数移动平均（α=0.2）避免抖动
5. **自动移除**：任务 `completed` 后自动从列表移除

### 5.3 工具箱页面（Notion 页面信息）

**流程**：
1. 输入 Page ID
2. 调用 `FetchDownloadListWithProbeAsync()`（复用下载页逻辑）
3. 统计文件数量和总大小（GB）
4. **不启动下载**，仅展示统计信息

---

## 6. 会话状态管理

### 6.1 问题背景

**问题现象**：
- 用户在下载页创建任务后，切换到其他页面
- 切换回下载页时，任务列表消失（但后台下载仍在进行）

**根本原因**：
- WPF 的 `Page` 在导航切换时会被卸载（Unload），页面级的 `ObservableCollection` 被销毁
- Python 后端任务仍在运行，但前端 UI 失去了对任务列表的引用

### 6.2 解决方案：Session 单例模式

**核心思想**：
- 创建 `DownloadSession` 和 `UploadSession` 两个单例类
- 将任务列表（`ObservableCollection`）和配置状态从页面级提升到单例级
- 页面通过属性访问单例的集合（而非自己持有集合）
- 页面 `Loaded` 事件中检查单例状态，恢复轮询

**实现对比**：

| 方案 | 数据所有权 | 页面切换效果 | 轮询恢复 |
|------|----------|------------|---------|
| ❌ **页面级集合** | `ObservableCollection` 在页面内 | 页面卸载→集合销毁 | ❌ 无法恢复 |
| ✅ **Session 单例** | `ObservableCollection` 在 Session 单例 | 页面卸载→集合依然存在 | ✅ Loaded 时恢复 |

### 6.3 DownloadPage 实现示例

```csharp
public partial class DownloadPage : Page
{
    // ⭐ 使用 Session 单例
    private readonly DownloadSession _session = DownloadSession.Instance;
    
    // ⭐ 通过属性访问单例集合（而非自己 new）
    public ObservableCollection<FileSelectItem> FileSelectionList => _session.FileSelectionList;
    public ObservableCollection<DownloadTaskStatus> DisplayTasks => _session.DisplayTasks;
    
    public DownloadPage()
    {
        InitializeComponent();
        
        // ⭐ Loaded 事件：恢复轮询
        Loaded += async (_, __) =>
        {
            if (_session.HasActiveDownloads)
            {
                await RefreshStatusesAsync(CancellationToken.None);
                if (!_downloadStatusTimer.IsEnabled)
                    _downloadStatusTimer.Start();
            }
        };
        
        // ⭐ Unloaded 事件：停止定时器但不清空数据
        Unloaded += (_, __) =>
        {
            if (_downloadStatusTimer.IsEnabled)
                _downloadStatusTimer.Stop();
        };
    }
    
    private async void SubmitDownload_Click(object sender, RoutedEventArgs e)
    {
        // ...启动下载...
        
        // ⭐ 标记有活跃任务
        _session.HasActiveDownloads = true;
        
        // 启动轮询
        if (!_downloadStatusTimer.IsEnabled)
            _downloadStatusTimer.Start();
    }
    
    private async void UpdateDownloadStatusesTick(object? sender, EventArgs e)
    {
        await RefreshStatusesAsync(CancellationToken.None);
        
        // ⭐ 如果没有任务了，标记无活跃任务
        if (DisplayTasks.Count == 0)
        {
            _downloadStatusTimer.Stop();
            _session.HasActiveDownloads = false;
        }
    }
}
```

### 6.4 UploadPage 实现示例

```csharp
public partial class UploadPage : Page
{
    // ⭐ 使用 Session 单例
    private readonly UploadSession _session = UploadSession.Instance;
    
    // ⭐ 通过属性访问单例集合
    public ObservableCollection<string> SelectedUploadFiles => _session.SelectedUploadFiles;
    public ObservableCollection<UploadTaskStatus> DisplayUploads => _session.DisplayUploads;
    
    public UploadPage()
    {
        InitializeComponent();
        
        // ⭐ Loaded 事件：恢复轮询
        Loaded += async (_, __) =>
        {
            if (_session.HasActiveUploads)
            {
                await RefreshUploadStatusesAsync(CancellationToken.None);
                if (!_statusTimer.IsEnabled)
                    _statusTimer.Start();
            }
        };
        
        // ⭐ Unloaded 事件：停止定时器但不清空数据
        Unloaded += (_, __) =>
        {
            if (_statusTimer.IsEnabled)
                _statusTimer.Stop();
        };
    }
    
    private async void ConfirmStart_Click(object sender, RoutedEventArgs e)
    {
        // ...启动上传...
        
        // ⭐ 保存 PageId 到 session
        _session.PageId = pageId;
        
        // ⭐ 标记有活跃任务
        _session.HasActiveUploads = true;
        
        // 启动轮询
        if (!_statusTimer.IsEnabled)
            _statusTimer.Start();
    }
}
```

### 6.5 关键要点总结

1. **Session 单例**：
   - `DownloadSession.Instance` / `UploadSession.Instance`
   - 持有 `ObservableCollection` 和状态标志

2. **页面属性访问**：
   - 通过 `=>` 属性返回单例集合
   - **不要**在页面构造函数中 `new ObservableCollection()`

3. **Loaded 事件恢复**：
   - 检查 `_session.HasActive*` 标志
   - 如果有活跃任务，恢复轮询定时器

4. **Unloaded 事件清理**：
   - 停止定时器（节省资源）
   - **不要清空**集合（保持数据持久化）

5. **TasksReset 事件**：
   - 设置页"重置任务"时触发
   - 清空集合并停止轮询

---

## 7. 日志与调试

### 7.1 C# 日志系统

**日志类**：`Utils/Logger.cs`

**日志目录**（v1.0.2 更新）：
- **新位置**（v1.0.2+）：`%LocalAppData%\NotionFilesManagement\logs\`
  - 完整路径示例：`C:\Users\[用户名]\AppData\Local\NotionFilesManagement\logs\`
  - 与配置文件位于同一父目录
  - 不受程序运行位置影响
- **旧位置**（v1.0.0-1.0.1）：`<程序目录>/logs/`（已废弃）

**文件命名**：`yyyyMMddHHmmss-C#.logs`（例如 `20260213143052-C#.logs`）

**日志级别**：
```csharp
Logger.Info("正常信息");
Logger.Warn("警告信息");
Logger.Error("错误信息", exception);
```

**性能计时**：
```csharp
using (Logger.Time("Python 调用耗时"))
{
    // ...执行 Python 调用...
}
// 输出: [Python 调用耗时] 1234 ms
```

**日志文件夹访问**（v1.0.2）：
- 工具箱页面提供"查看日志文件"功能
- 点击"打开"按钮可直接在文件资源管理器中打开日志文件夹（AppData位置）
- 如果日志文件夹不存在，会自动创建
- `Logger.LogDirectory` 属性提供日志目录路径供其他模块使用

**为什么改用 AppData？**（v1.0.2 变更原因）
- ✅ 与配置文件位置一致（`%AppData%\NotionFilesManagement\config.json`）
- ✅ 不受单文件发布影响（避免日志保存到临时目录）
- ✅ 避免权限问题（程序安装目录可能没有写入权限）
- ✅ 符合 Windows 应用标准做法

### 7.2 Python 日志

**日志模块**：`Scripts/logger.py`

**日志目录**（v1.0.3-Beta.2 更新）：
- **位置**：`%LocalAppData%\NotionFilesManagement\logs\`
  - 完整路径示例：`C:\Users\[用户名]\AppData\Local\NotionFilesManagement\logs\`
  - 与 C# 日志位于同一目录
  - 不受程序运行位置影响

**文件命名**：`yyyyMMddHHmmss-Py.logs`（例如 `20260213150203-Py.logs`）

**日志级别**：
```python
from logger import PythonLogger

PythonLogger.debug("调试信息")
PythonLogger.info("正常信息")
PythonLogger.warning("警告信息")
PythonLogger.error("错误信息", exc_info=exception)
```

**初始化**：
- Python 日志系统在 `Main.__init__` 时自动初始化
- 日志目录由 C# 通过 `PythonBackendHost` 传递给 Python
- 如果未提供日志目录，会回退到控制台输出

**日志格式**：
```
[2026-02-13 15:02:03][T12345][INFO] Main initialized: dl_workers=3, ul_workers=3
[2026-02-13 15:02:04][T12346][WARNING] 触发限制(429)，第 1 次重试，等待 2s...
[2026-02-13 15:02:05][T12347][ERROR] 已达到最大重试次数，任务失败: Connection timeout
```

**使用位置**：
- `Scripts/main.py`：初始化日志，记录主要操作
- `Scripts/notion.py`：API 调用错误和重试信息
- `Scripts/download.py`：下载任务调试信息（通过 `_dbg` 方法）
- `Scripts/upload.py`：上传任务调试信息（通过 `_dbg` 方法）

**为什么与 C# 日志统一？**（v1.0.3-Beta.2 变更原因）
- ✅ 便于统一管理和查看日志
- ✅ 工具箱"查看日志文件"功能可以同时查看 C# 和 Python 日志
- ✅ 问题排查时无需切换目录
- ✅ 符合统一日志管理的最佳实践

### 7.3 调试技巧

#### 7.3.1 检查 Python 运行时

```csharp
// App.xaml.cs
if (!File.Exists(pythonDll))
{
    MessageBox.Show($"Python DLL 不存在: {pythonDll}");
    Shutdown();
}
```

#### 7.3.2 捕获 Python 异常

```csharp
try
{
    using (Py.GIL())
    {
        // ...Python 调用...
    }
}
catch (PythonException ex)
{
    Logger.Error($"Python 异常: {ex.Message}", ex);
    MessageBox.Show($"Python 执行失败:\n{ex.Message}");
}
```

#### 7.3.3 检查 sys.path

```csharp
using (Py.GIL())
{
    dynamic sys = Py.Import("sys");
    foreach (var path in sys.path)
    {
        Logger.Info($"sys.path: {path}");
    }
}
```

#### 7.3.4 检查 Python 对象类型

```csharp
using (Py.GIL())
{
    dynamic result = pyFunc.Invoke();
    Logger.Info($"Python 返回类型: {result.GetType()}");
    Logger.Info($"Python __class__.__name__: {result.__class__.__name__}");
}
```

---

## 8. 常见问题与Bug修复记录

### 8.1 已修复问题

#### 8.1.1 页面切换导致任务列表消失 ✅

**问题描述**：
- 下载/上传页面创建任务后，切换到其他页面再切换回来，任务列表消失
- 后台任务仍在运行，但 UI 无法显示

**根本原因**：
- 任务列表是页面级的 `ObservableCollection`
- 页面卸载时集合被销毁

**解决方案**：
- 创建 `DownloadSession.cs` 和 `UploadSession.cs` 单例
- 将任务列表提升到单例级
- 页面 `Loaded` 时恢复轮询状态

**修复提交**：`commit: fix page switch causing task list disappearance`

**相关文件**：
- `Services/DownloadSession.cs`（新增）
- `Services/UploadSession.cs`（新增）
- `Views/DownloadPage.xaml.cs`（修改）
- `Views/UploadPage.xaml.cs`（修改）

#### 8.1.2 Notion URL 过期导致下载失败 ✅（已升级为自动刷新）

**问题描述**：
- Notion 文件 URL 有过期时间（通常 1 小时）
- 用户获取列表后延迟下载，URL 已过期
- 旧方案仅在下载前做静态预检，下载中过期仍会失败

**解决方案（v1.2.0-Beta.7 升级）**：
- `get_download_url()` 新增 `block_id`（Notion block ID）和 `created_time`（链接获取时间 UTC）
- `Notion.refresh_file_url(block_id)` 通过 `/blocks/{block_id}` API 获取新鲜 URL
- `Download._worker()` 检测 HTTP 401/403/410，自动调用刷新回调获取新 URL 并重试（最多 2 次）
- 下载期间状态为 `"refreshing"`，刷新成功后自动继续下载
- 移除前端 `expiry_utc` 静态预检（后端已自动处理）

**代码示例（Python 后端）**：
```python
# notion.py — 刷新单个文件的 URL
def refresh_file_url(self, block_id: str) -> dict | None:
    res = requests.get(f"{self.url}/blocks/{block_id}", headers=self.default_headers)
    block = res.json()
    return {"url": block["file"]["file"]["url"], "expiry_time": ...}

# download.py — 下载失败时自动刷新
# _do_download() 检测 HTTP 401/403/410 → 返回 is_expired=True
# _worker() 循环：调用 url_refresh_callback() 获取新 URL → 重试下载
```

#### 8.1.3 GIL 死锁问题 ✅

**问题描述**：
- 多个 WPF 事件同时触发 Python 调用
- 导致 GIL 死锁或崩溃

**解决方案**：
- 创建 `PythonBackendHost` 统一入口
- 使用 `SemaphoreSlim _pyLock` 串行化所有 Python 调用
- 每次调用包裹 `Py.GIL()`

**代码示例**：
```csharp
private readonly SemaphoreSlim _pyLock = new(1, 1);

public async Task<T> RunPython<T>(Func<T> action)
{
    await _pyLock.WaitAsync();
    try
    {
        using (Py.GIL())
        {
            return action();
        }
    }
    finally
    {
        _pyLock.Release();
    }
}
```

### 8.2 已知限制

#### 8.2.1 Python 运行时架构匹配

- **限制**：`python311.dll` 架构必须与程序架构一致（x64/x86）
- **影响**：如果不匹配，程序启动时初始化失败
- **解决**：发布时确保 Python 环境与目标架构一致

#### 8.2.2 Notion API 速率限制

- **限制**：Notion API 有速率限制（3 requests/second）
- **影响**：批量上传时可能触发 429 错误
- **解决**：Python 后端使用令牌桶限流（`rps=3.0, burst=4`）

#### 8.2.3 大文件上传内存占用

- **限制**：上传大文件（>100MB）时内存占用较高
- **影响**：同时上传多个大文件可能导致内存不足
- **解决**：
  - 限制并发数（`MaxUploadWorkers=3`）
  - 使用分片上传（`part_size_bytes=15MB`）

### 8.3 调试清单

**问题**：程序启动失败

- [ ] 检查 `PythonEnv/python311.dll` 是否存在
- [ ] 检查 Python DLL 架构是否匹配（x64/x86）
- [ ] 查看日志文件 `logs/*.logs`

**问题**：Python 调用失败

- [ ] 检查 `sys.path` 是否包含 `Scripts/` 目录
- [ ] 检查 Python 模块是否存在（`main.py`, `notion.py` 等）
- [ ] 检查是否有 `PythonException` 异常信息

**问题**：任务列表消失

- [ ] 确认使用 `Session.Instance` 而非页面级集合
- [ ] 检查 `Loaded` 事件是否恢复轮询
- [ ] 检查 `HasActive*` 标志是否正确设置

**问题**：下载/上传失败

- [ ] 检查 Notion Token 是否有效
- [ ] 检查网络连接
- [ ] 查看 Python 日志（如果启用）
- [ ] 检查文件权限（保存目录是否可写）

---

## 9. 开发规范与最佳实践

### 9.1 代码规范

#### 9.1.1 命名规范

| 类型 | 规范 | 示例 |
|------|------|------|
| **类名** | PascalCase | `DownloadSession` |
| **方法名** | PascalCase | `FetchDownloadListWithProbeAsync` |
| **私有字段** | `_camelCase` | `_statusTimer` |
| **属性** | PascalCase | `DisplayTasks` |
| **局部变量** | camelCase | `pageId` |
| **常量** | PascalCase | `SpeedEmaAlpha` |

#### 9.1.2 异步方法规范

- 异步方法名以 `Async` 结尾
- 返回 `Task` 或 `Task<T>`
- 接受 `CancellationToken` 参数（可选）

```csharp
public async Task<List<DownloadTaskStatus>> GetDownloadStatusesAsync(CancellationToken token)
{
    // ...
}
```

#### 9.1.3 UI 线程规范

- **不要**在 UI 线程执行耗时操作
- 使用 `await` 等待异步操作
- **不要**使用 `.Wait()` 或 `.Result`（可能死锁）

```csharp
// ❌ 错误：阻塞 UI 线程
var result = _svc.GetDownloadStatusesAsync(token).Result;

// ✅ 正确：异步等待
var result = await _svc.GetDownloadStatusesAsync(token);
```

#### 9.1.4 异常处理规范

- 捕获具体异常类型
- 记录日志
- 向用户展示友好提示

```csharp
try
{
    // ...
}
catch (PythonException ex)
{
    Logger.Error("Python 调用失败", ex);
    MessageBox.Show($"操作失败: {ex.Message}");
}
catch (Exception ex)
{
    Logger.Error("未知错误", ex);
    MessageBox.Show("发生未知错误，请查看日志。");
}
```

### 9.2 Python 调用规范

#### 9.2.1 统一使用 NotionBackendService

- **不要**直接在页面中调用 `PythonBackendHost`
- **应该**通过 `NotionBackendService` 调用

```csharp
// ❌ 错误：直接调用
await PythonBackendHost.Instance.RunPython(() =>
{
    // ...
});

// ✅ 正确：通过 Service
await _svc.StartDownloadAsync(files, saveDir, token);
```

#### 9.2.2 类型转换规范

- 使用 `PyConvert` 辅助类转换基础类型
- 使用 `PythonHelpers` 访问 Python 对象属性

```csharp
// 读取 Python dict
var pyDict = pyObj as PyDict;
var value = PyConvert.ToString(pyDict["key"]);

// 读取 Python list
var pyList = pyObj as PyList;
foreach (var item in pyList)
{
    // ...
}
```

### 9.3 XAML 绑定规范

#### 9.3.1 数据绑定

- Model 类继承 `ObservableObject`
- 属性使用 `OnPropertyChanged()` 通知

```csharp
public class UploadTaskStatus : ObservableObject
{
    private string _status = "";
    public string Status
    {
        get => _status;
        set
        {
            if (_status != value)
            {
                _status = value;
                OnPropertyChanged();
            }
        }
    }
}
```

#### 9.3.2 字段命名兼容性

- Python 后端使用 `snake_case`
- C# 前端可以保持 `snake_case` 以避免映射问题
- 或使用属性映射（更复杂）

```csharp
// ✅ 方案1：保持 snake_case（简单）
public class FileSelectItem : ObservableObject
{
    public string url { get; set; }
    public string name { get; set; }
    public double size_mb { get; set; }
    public string block_id { get; set; }       // Notion block ID（用于刷新过期 URL）
    public string created_time { get; set; }   // 链接获取时间 UTC
}

// ✅ 方案2：映射（灵活）
public class FileSelectItem : ObservableObject
{
    public string Url { get; set; }
    public string Name { get; set; }
    public double SizeMB { get; set; }
    public string BlockId { get; set; }
    public string CreatedTime { get; set; }
    
    public static FileSelectItem FromPython(PyDict pyDict)
    {
        return new FileSelectItem
        {
            Url = PyConvert.ToString(pyDict["url"]),
            Name = PyConvert.ToString(pyDict["name"]),
            SizeMB = PyConvert.ToDouble(pyDict["size_mb"]),
            BlockId = PyConvert.ToString(pyDict["block_id"]),
            CreatedTime = PyConvert.ToString(pyDict["created_time"])
        };
    }
}
```

### 9.4 会话状态管理规范

#### 9.4.1 使用 Session 单例

- 任务列表、配置状态使用 Session 单例
- 避免页面级集合

```csharp
// ❌ 错误：页面级集合
public ObservableCollection<UploadTaskStatus> DisplayUploads { get; } = new();

// ✅ 正确：Session 单例
private readonly UploadSession _session = UploadSession.Instance;
public ObservableCollection<UploadTaskStatus> DisplayUploads => _session.DisplayUploads;
```

#### 9.4.2 Loaded 事件恢复

- 页面 `Loaded` 时检查 Session 状态
- 如有活跃任务，恢复轮询

```csharp
Loaded += async (_, __) =>
{
    if (_session.HasActiveUploads)
    {
        await RefreshUploadStatusesAsync(CancellationToken.None);
        if (!_statusTimer.IsEnabled)
            _statusTimer.Start();
    }
};
```

#### 9.4.3 Unloaded 事件清理

- 停止定时器
- **不要**清空集合

```csharp
Unloaded += (_, __) =>
{
    if (_statusTimer.IsEnabled)
        _statusTimer.Stop();
    // ❌ 不要清空集合: DisplayUploads.Clear();
};
```

### 9.5 新增功能开发流程

#### Step 1：设计 API

1. 在 `Scripts/main.py` 添加方法
2. 定义输入参数和返回格式

```python
def get_page_info(self, page_id: str):
    """获取页面信息"""
    return {
        "title": "...",
        "file_count": 10,
        "total_size_mb": 1234.56
    }
```

#### Step 2：封装到 Service

1. 在 `NotionBackendService.cs` 添加方法
2. 处理类型转换和异常

```csharp
public async Task<(string Title, int FileCount, double TotalSizeMB)> GetPageInfoAsync(string pageId, CancellationToken token)
{
    return await _host.RunPython(() =>
    {
        using (Py.GIL())
        {
            var result = _main.get_page_info(pageId);
            return (
                PyConvert.ToString(result["title"]),
                PyConvert.ToInt32(result["file_count"]),
                PyConvert.ToDouble(result["total_size_mb"])
            );
        }
    });
}
```

#### Step 3：UI 调用

1. 在页面添加按钮和事件处理
2. 调用 Service 方法
3. 更新 UI

```csharp
private async void GetPageInfo_Click(object sender, RoutedEventArgs e)
{
    var pageId = PageIdInput.Text.Trim();
    var (title, count, sizeMB) = await _svc.GetPageInfoAsync(pageId, CancellationToken.None);
    
    MessageBox.Show($"页面: {title}\n文件数: {count}\n总大小: {sizeMB:F2} MB");
}
```

---

## 10. 部署与发布

### 10.1 发布配置

**发布模式**：
- **Framework-Dependent**（依赖框架）：需要用户安装 .NET 8.0 运行时
- **Self-Contained**（自包含）：包含 .NET 运行时，体积较大

**推荐**：Self-Contained（用户无需安装 .NET）

### 10.2 发布脚本

项目提供两个发布脚本：

#### 10.2.1 PUBLIST-framework-dependent.bat

```batch
dotnet publish -c Release -r win-x64 --self-contained false /p:PublishSingleFile=false
```

- 输出目录：`bin/Release/net8.0-windows/win-x64/publish/`
- 需要用户安装 .NET 8.0 运行时

#### 10.2.2 PUBLIST-self-contained.bat（推荐）

```batch
dotnet publish -c Release -r win-x64 --self-contained true /p:PublishSingleFile=false
```

- 输出目录：`bin/Release/net8.0-windows/win-x64/publish/`
- 包含 .NET 运行时，无需用户安装

### 10.3 发布检查清单

**发布前检查**：

- [ ] 确认 `PythonEnv/python311.dll` 存在且架构匹配
- [ ] 确认 `Scripts/` 目录包含所有 Python 文件
- [ ] 测试 Python 后端功能正常
- [ ] 检查日志输出正常
- [ ] 测试配置文件读写正常

**发布后检查**：

- [ ] 检查发布目录结构
- [ ] 测试启动程序
- [ ] 测试下载功能
- [ ] 测试上传功能
- [ ] 测试设置保存

### 10.4 Python 环境准备

#### 10.4.1 创建独立 Python 环境

```bash
# 1. 下载 Python 3.11 嵌入版（embeddable package）
# https://www.python.org/downloads/windows/

# 2. 解压到 PythonEnv/
python-3.11.x-embed-amd64.zip -> PythonEnv/

# 3. 安装依赖
PythonEnv\python.exe -m pip install requests
PythonEnv\python.exe -m pip install <其他依赖>

# 4. 确认 python311.dll 存在
dir PythonEnv\python311.dll
```

#### 10.4.2 发布时包含 Python 环境

- 在 `.csproj` 中已配置：
  ```xml
  <Content Include="PythonEnv\**">
      <CopyToOutputDirectory>PreserveNewest</CopyToOutputDirectory>
  </Content>
  ```

- 发布时自动复制 `PythonEnv/` 到输出目录

### 10.5 打包安装程序（可选）

**工具推荐**：
- **Inno Setup**：免费，功能强大
- **WiX Toolset**：基于 XML，更灵活
- **Advanced Installer**：图形化界面，易用

**Inno Setup 示例**：

```iss
[Setup]
AppName=Notion Files Management
AppVersion=2.0
DefaultDirName={pf}\NotionFilesManagement
DefaultGroupName=Notion Files Management
OutputDir=installer
OutputBaseFilename=NotionFilesManagement-Setup

[Files]
Source: "bin\Release\net8.0-windows\win-x64\publish\*"; DestDir: "{app}"; Flags: recursesubdirs

[Icons]
Name: "{group}\Notion Files Management"; Filename: "{app}\Notion-Files-Management.exe"
Name: "{commondesktop}\Notion Files Management"; Filename: "{app}\Notion-Files-Management.exe"
```

---

## 12. 版本管理规范

### 12.1 版本号格式

版本号遵循 **{major}.{minor}.{patch}-{State}** 格式：

```
1.0.0-Beta
1.0.0-Stable
1.1.0-Beta
2.0.0-Stable
```

| 字段 | 说明 |
|------|------|
| major | 重大架构变更或不兼容更新 |
| minor | 新增功能，向后兼容 |
| patch | Bug 修复、细节优化 |
| State | 发布状态（见下表） |

### 12.2 发布状态（State）

| State | 权重 | 含义 | 适用场景 |
|-------|------|------|----------|
| **Beta** | 1（较低）| 功能基本完整，可能存在已知问题 | 公开测试、早期使用者 |
| **Stable** | 2（较高）| 经过充分测试，推荐正式使用 | 生产环境、普通用户 |

> 权重越高代表越成熟稳定。State 比较时 Beta < Stable。

### 12.3 版本比较规则

检查版本更新时，客户端与服务端版本按以下规则比较（见 `SettingsPage.xaml.cs → CompareVersionStrings`）：

| 本地版本 | 服务端版本 | 结果 | 提示 |
|---------|---------|------|------|
| `1.0.0-Beta`   | `1.0.0-Beta`   | ✅ 已是最新 | 当前已是最新版本 |
| `1.0.0-Stable` | `1.0.0-Stable` | ✅ 已是最新 | 当前已是最新版本 |
| `1.0.0-Beta`   | `1.0.0-Stable` | ⬆️ 稳定版升级 | 相同版本号，官方已发布正式版，建议升级 |
| `1.0.0-Stable` | `1.0.0-Beta`   | ✅ 已是最新 | 本地已比服务端更稳定 |
| `1.0.0-Beta`   | `1.1.0-Beta`   | 🆕 有新版本 | 发现新版本 1.1.0-Beta |
| `1.0.0-Stable` | `1.1.0-Beta`   | 🆕 有新版本 | 发现新版本 1.1.0-Beta |
| `1.1.0-Beta`   | `1.0.0-Stable` | ✅ 已是最新 | 本地版本号更高（内测/预览版）|
| `1.0.0-Beta`   | `2.0.0-Stable` | 🆕 有新版本 | 发现新版本 2.0.0-Stable |

### 12.4 版本号存储位置（v2.4.0 起）

**⚠️ 重要变更**：从 v2.4.0 开始，版本号管理方式已优化，不再使用 `config.json`。

#### 新的版本号管理方式

**存储位置**：`Notion-Files-Management.csproj` 文件的 `<PropertyGroup>` 中

```xml
<PropertyGroup>
  <!-- 版本信息 -->
  <Version>2.4.0</Version>
  <AssemblyVersion>2.4.0.0</AssemblyVersion>
  <FileVersion>2.4.0.0</FileVersion>
  <InformationalVersion>2.4.0-Stable</InformationalVersion>
</PropertyGroup>
```

**读取方式**：通过 `AppVersion` 静态类（`AppVersion.cs`）

```csharp
// 获取完整版本号（包含状态，不含 Git commit hash）
string version = AppVersion.Current;  // 2.4.0-Stable

// 获取带 v 前缀的版本字符串
string displayVersion = AppVersion.FullVersionString;  // v2.4.0-Stable

// 获取数字版本号（不含状态）
string numericVersion = AppVersion.NumericVersion;  // 2.4.0

// 获取版本状态
string status = AppVersion.Status;  // Stable
```

**注意**：`AppVersion.Current` 会自动清理 Git commit hash（`+` 号后面的部分），确保版本号简洁且适合显示和比较。

**优势**：
- ✅ **单一数据源**：版本号只在 `.csproj` 中定义一次
- ✅ **自动同步**：无需在多处手动维护版本号
- ✅ **标准化**：遵循 .NET 官方版本管理最佳实践
- ✅ **类型安全**：通过静态类访问，避免字符串硬编码
- ✅ **自动清理**：自动去除构建工具添加的 Git hash，保持版本号简洁

### 12.5 版本号更新流程

#### 1. 修改版本号

编辑 `Notion-Files-Management.csproj` 文件：

```xml
<InformationalVersion>2.5.0-Beta</InformationalVersion>
```

#### 2. 验证版本号

运行程序后，检查以下位置：
- 设置页面的"当前版本"显示
- 日志文件中的版本号记录
- 程序文件属性中的版本信息

#### 3. 发布新版本

1. 提交代码到仓库
2. 创建 Git Tag：`git tag v2.5.0-Beta`
3. 推送 Tag：`git push origin v2.5.0-Beta`
4. 构建发布包（使用发布脚本）
5. 更新服务端 `version.json` 文件

### 12.6 展示位置

| 页面 | 控件 | 内容 |
|------|------|------|
| 主页（DashboardPage） | `TxtVersion` | `v1.0.0-Beta` |
| 设置页（SettingsPage）| `TxtCurrentVersion` | `当前版本：v1.0.0-Beta` |

---

## 附录

### A. 快速参考

#### A.1 核心类速查

| 类名 | 路径 | 职责 |
|------|------|------|
| `App` | `App.xaml.cs` | 应用启动，初始化 pythonnet，应用主题色（v1.1.0-Beta+） |
| `MainWindow` | `MainWindow.xaml.cs` | 主窗口，导航容器，应用背景材质配置（v1.1.0-Beta+），支持图片/视频背景渲染（v1.2.0-Beta+） |
| `ConfigManager` | `AppConfig.cs` | 配置文件读写 |
| `PythonBackendHost` | `Services/PythonBackendHost.cs` | Python 调用 GIL 安全层 |
| `NotionBackendService` | `Services/NotionBackendService.cs` | Python 调用门面服务 |
| `DownloadSession` | `Services/DownloadSession.cs` | 下载会话状态（单例） |
| `UploadSession` | `Services/UploadSession.cs` | 上传会话状态（单例） |
| `DownloadPage` | `Views/DownloadPage.xaml.cs` | 下载页面 |
| `UploadPage` | `Views/UploadPage.xaml.cs` | 上传页面 |
| `ToolsPage` | `Views/ToolsPage.xaml.cs` | 工具箱页面 |
| `SettingsPage` | `Views/SettingsPage.xaml.cs` | 设置页面（包含主题色设置、背景材质设置（含图片/视频背景，v1.2.0-Beta+），v1.1.0-Beta+；贪心高度平衡自动排版，v1.2.0-Beta.2+） |
| `InlineColorPicker` | `Views/Controls/InlineColorPicker.xaml.cs` | 嵌入式颜色选择器控件（v1.1.0-Beta+） |

#### A.2 Python API 速查

| 方法 | 参数 | 返回值 | 说明 |
|------|------|--------|------|
| `get_download_list(page_id)` | `page_id: str` | `dict` | 获取下载列表 + 启动探测（列表含 `block_id`、`created_time`） |
| `download_list_processing(probe_id)` | `probe_id: str` | `dict` | 获取探测进度 |
| `download_notion_files(list, dir)` | `list: list, dir: str` | `str` | 启动下载任务（自动注册 URL 刷新回调） |
| `get_download_statuses()` | - | `list[dict]` | 获取下载状态列表（含 `created_time`，状态含 `"refreshing"`） |
| `upload_notion_files(page_id, files)` | `page_id: str, files: list[str]` | `str` | 启动上传任务 |
| `get_upload_statuses()` | - | `list[dict]` | 获取上传状态列表 |
| `shutdown()` | - | - | 释放资源 |

**Notion 内部 API**：

| 方法 | 说明 |
|------|------|
| `Notion.refresh_file_url(block_id)` | 通过 block_id 重新获取文件下载 URL，返回 `{"url": ..., "expiry_time": ...}` 或 `None` |

#### A.3 配置文件格式

```json
{
  "NotionToken": "secret_xxx",
  "NotionBaseUrl": "https://api.notion.com/v1",
  "MaxDownloadWorkers": 3,
  "MaxUploadWorkers": 3,
  "ThemeAccentColor": "#1E90FF",
  "BackgroundMaterial": "Mica",
  "AcrylicOpacity": 0.8,
  "BackgroundImagePath": "",
  "BackgroundImageBlur": 0,
  "BackgroundImageOpacity": 0.3
}
```

**路径**：`%AppData%\NotionFilesManagement\config.json`

**字段说明**：
- `ThemeAccentColor`: 主题色（格式：`#RRGGBB`，默认：`#1E90FF`，v1.1.0-Beta+）
- `BackgroundMaterial`: 背景材质类型（可选值：`"Mica"`（云母）、`"Acrylic"`（亚克力）或 `"Image"`（图片/视频），默认：`"Mica"`，v1.1.0-Beta+，v1.2.0-Beta+ 新增 Image）
- `AcrylicOpacity`: 亚克力材质不透明度（范围：0.0-1.0，默认：0.8，仅在 `BackgroundMaterial` 为 `"Acrylic"` 时生效，v1.1.0-Beta+）
- `BackgroundImagePath`: 背景图片/视频绝对路径（仅在 `BackgroundMaterial` 为 `"Image"` 时生效，v1.2.0-Beta+）
- `BackgroundImageBlur`: 背景模糊度（范围：0-50 像素，默认：0，v1.2.0-Beta+）
- `BackgroundImageOpacity`: 背景不透明度（范围：0.0-1.0，默认：0.3，v1.2.0-Beta+）

### B. 相关资源

#### B.1 文档链接

- [Notion API 官方文档](https://developers.notion.com/)
- [pythonnet 文档](https://pythonnet.github.io/)
- [WPF-UI 文档](https://wpfui.lepo.co/)

#### B.2 依赖版本

- .NET 8.0
- pythonnet 3.0.5
- WPF-UI 4.2.0
- Python 3.11

### C. 维护记录

**说明**：从 v1.0.2-Beta.1 开始，采用新的版本命名规则 `X.Y.Z-Status.N`（程序版本.文档修订号）

| 日期 | 版本号 | 变更 | 维护者 |
|------|--------|------|--------|
| 2026-02-18 | **1.2.0-Beta.7** | **[功能]** 下载链接过期自动刷新；`get_download_url()` 新增 `block_id`/`created_time` 字段；新增 `Notion.refresh_file_url(block_id)` 方法；`Download._worker()` 检测 HTTP 401/403/410 自动刷新 URL 并重试（最多 2 次）；新增 `"refreshing"` 下载状态；C# 侧 `FileSelectItem` 新增 `block_id`/`created_time`，`DownloadTaskStatus` 新增 `created_time`；移除前端 `expiry_utc` 静态预检 | - |
| 2026-02-18 | **1.2.0-Beta.6** | **[清理]** 全面审查 C# 代码冗余；移除 7 个死代码文件（IconThemeLabPage、ColorPickerWindow、PageInfoResultWindow、PageIdInputWindow、ProbeProgressWindow）；移除 ConfigData.AppVersion 遗留属性；移除 Logger 未使用的 InitConsole/Warning/P-Invoke；移除 PythonBackendHost 未调用的 RunPython 重载；修复 UiHelpers 重复关键词 | - |
| 2026-02-18 | **1.2.0-Beta.5** | **[修复]** 定位滚动问题根因：WPF-UI NavigationView 已有 ScrollViewer 包裹页面内容，嵌套 ScrollViewer 导致内层 ScrollableHeight=0；移除内嵌 ScrollViewer，改为运行时发现祖先 ScrollViewer 并驱动；新增视觉树诊断日志 | - |
| 2026-02-18 | **1.2.0-Beta.4** | **[修复]** 深入排查鼠标滚轮问题；改用 AddHandler(handledEventsToo:true) 注册方式确保事件触发；添加 ScrollViewer 诊断日志；添加 Focusable/CanContentScroll 属性优化 | - |
| 2026-02-18 | **1.2.0-Beta.3** | **[修复]** 修复设置页面鼠标滚轮无法滚动的问题；Slider/ComboBox 吞掉 MouseWheel 冒泡事件；使用 PreviewMouseWheel 隧道事件拦截解决 | - |
| 2026-02-18 | **1.2.0-Beta.2** | **[优化]** 设置页面自动排版重构；使用贪心高度平衡算法动态分配节区块到两列；将"外观"卡片拆分为"主题色"和"背景材质"两个独立卡片；子面板可见性变化时自动重平衡；新增 ScrollViewer 支持滚动；消除两列高度"凸起"问题 | - |
| 2026-02-18 | **1.2.0-Beta.1** | **[新功能]** 背景材质新增"图片"选项；支持自定义图片（PNG/JPG/BMP/GIF）或视频（MP4）背景；支持模糊度（0-50px）和不透明度（0-100%）调节；视频背景循环播放；无效路径自动回退 Mica；程序版本升级至 1.2.0-Beta | - |
| 2026-02-15 | **1.1.1-Beta.1** | **[重要]** 设置页面响应式布局优化；根据窗口大小自动排列组件（窗口宽度 ≥ 1200px 时两列布局，< 1200px 时单列布局）；充分利用屏幕空间，避免右侧空白；程序版本升级至 1.1.1-Beta | - |
| 2026-02-15 | **1.1.0-Beta.4** | **[重要]** 设置页面响应式布局优化；根据窗口大小自动排列组件（窗口宽度 ≥ 1200px 时两列布局，< 1200px 时单列布局）；充分利用屏幕空间，避免右侧空白 | - |
| 2026-02-15 | **1.1.0-Beta.3** | **[重要]** 工具箱页面功能分类优化；将"查看日志文件"和"报告错误"从"Notion 相关"块移出，创建新的"软件工具"功能块 | - |
| 2026-02-15 | **1.1.0-Beta.2** | **[重要]** 新增背景材质配置功能；支持云母/亚克力材质选择；支持亚克力不透明度调节（0.0-1.0）；背景材质配置持久化；应用启动时自动应用背景材质；提供系统笔刷特性说明 | - |
| 2026-02-15 | **1.1.0-Beta.1** | **[重要]** 新增主题色（调色盘）设置功能；支持 HSV/RGB 颜色空间选择；提供预设颜色快速选择；主题色配置持久化；应用启动时自动应用主题色 | - |
| 2026-02-13 | **1.0.3-Beta.2** | **[重要]** 新增 Python 后端日志功能；日志保存在与 C# 相同的目录；统一日志管理 | - |
| 2026-02-13 | **1.0.3-Beta.1** | **[重要]** 修复主页版本号显示不一致问题（统一使用 AppVersion 类）；版本号升级至 1.0.3-Beta；统一版本号管理系统 | - |
| 2026-02-13 | **1.0.2-Beta.1** | **[重要]** 日志位置改为 AppData 目录（避免单文件发布问题）；工具箱新增"查看日志文件"功能；删除调试功能；版本命名规则重构 | - |
| 2026-02-13 | v2.4.3 | 日志系统改进：确保打包后日志文件夹自动创建；工具箱新增"查看日志文件"功能；删除调试用"图标与主题实验室"功能 | - |
| 2026-02-12 | v2.4.2 | 设置页：关于/版本更新的更新内容条目按块宽度自动换行（避免被裁剪） | - |
| 2026-02-13 | v2.4.1 | 修复版本显示问题（清理 Git hash）+ 改进版本比较逻辑 + 支持更新内容换行 | - |
| 2026-02-13 | v2.4 | 版本号管理优化（迁移至 .csproj）+ 版本检查功能重新实现 + 新增 AppVersion 类 | - |
| 2026-02 | v2.3 | 下载/上传/工具箱页：Page ID 自动格式化（无连字符→UUID）+ 输入校验与错误提示 | - |
| 2026-02 | v2.2 | 版本号迁移至 config.json；主页新增官网/GitHub/赞助按钮；版本比较支持 Stable/Beta 状态 | - |
| 2026-02 | v2.1 | 设置页新增检查版本更新功能，支持 HTTP/HTTPS 双协议兼容 | - |
| 2026-02 | v2.0 | 修复页面切换任务消失问题，新增 UploadSession | - |
| 2026-01 | v1.5 | 重构前端，引入 NotionBackendService | - |
| 2025-12 | v1.0 | 初始版本 | - |

---

## 联系方式

**问题反馈**：[GitHub Issues](https://github.com/your-repo/issues)  
**技术讨论**：[Discussions](https://github.com/your-repo/discussions)

---

**最后更新**: 2026年2月18日（下载链接过期自动刷新功能）
