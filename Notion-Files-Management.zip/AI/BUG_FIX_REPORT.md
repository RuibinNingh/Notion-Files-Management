# Bug 修复说明文档

## 问题描述

**Bug**: 上传页面创建任务后切换到其他页面，上传仍在继续，但任务不再渲染

**影响范围**: 上传功能

**严重程度**: 高

---

## 根本原因分析

### 问题现象
1. 用户在上传页面选择文件并创建上传任务
2. 切换到其他页面（如下载页、设置页等）
3. Python 后端的上传任务仍在继续执行
4. 切换回上传页面后，任务列表为空，无法看到上传进度
5. 上传完成后也无法看到结果

### 根本原因
**WPF 页面生命周期问题**：

1. **页面级集合销毁**
   - `UploadPage.xaml.cs` 的 `DisplayUploads` 和 `SelectedUploadFiles` 是页面级的 `ObservableCollection`
   - WPF 导航框架在切换页面时会卸载（Unload）当前页面
   - 页面卸载时，这些集合会被垃圾回收销毁

2. **缺少状态持久化**
   - 下载页面有 `DownloadSession` 单例来保持状态
   - 上传页面缺少对应的会话管理机制

3. **缺少轮询恢复机制**
   - 下载页面在 `Loaded` 事件中会检查是否有活跃任务并恢复轮询
   - 上传页面没有实现类似的恢复机制

### 对比：下载页面的正确实现

下载页面通过以下机制避免了这个问题：

```csharp
// 1. 使用 Session 单例
private readonly DownloadSession _session = DownloadSession.Instance;
public ObservableCollection<DownloadTaskStatus> DisplayTasks => _session.DisplayTasks;

// 2. Loaded 事件恢复轮询
Loaded += async (_, __) =>
{
    if (_session.HasActiveDownloads)
    {
        await RefreshStatusesAsync(CancellationToken.None);
        if (!_downloadStatusTimer.IsEnabled)
            _downloadStatusTimer.Start();
    }
};

// 3. Unloaded 事件停止定时器但不清空数据
Unloaded += (_, __) =>
{
    if (_downloadStatusTimer.IsEnabled)
        _downloadStatusTimer.Stop();
};
```

---

## 解决方案

### 1. 创建 UploadSession 单例类

**文件**: `Services/UploadSession.cs` (新增)

**功能**:
- 持有上传任务列表 (`DisplayUploads`)
- 持有已选文件列表 (`SelectedUploadFiles`)
- 持有 EMA 速度平滑字典 (`SpeedEma`)
- 保存 PageId 状态
- 标记是否有活跃上传任务 (`HasActiveUploads`)

**代码结构**:
```csharp
public sealed class UploadSession
{
    public static UploadSession Instance { get; } = new UploadSession();
    
    public ObservableCollection<UploadTaskStatus> DisplayUploads { get; } = new();
    public ObservableCollection<string> SelectedUploadFiles { get; } = new();
    public Dictionary<string, double> SpeedEma { get; } = new();
    public string PageId { get; set; } = "";
    public bool HasActiveUploads { get; set; } = false;
    
    private UploadSession() { }
}
```

### 2. 修改 UploadPage 使用 Session

**文件**: `Views/UploadPage.xaml.cs` (修改)

**主要改动**:

#### 改动 1: 使用 Session 单例替代页面级集合

```csharp
// 修改前
public ObservableCollection<string> SelectedUploadFiles { get; } = new();
public ObservableCollection<UploadTaskStatus> DisplayUploads { get; } = new();
private readonly Dictionary<string, double> _speedEma = new();

// 修改后
private readonly UploadSession _session = UploadSession.Instance;
public ObservableCollection<string> SelectedUploadFiles => _session.SelectedUploadFiles;
public ObservableCollection<UploadTaskStatus> DisplayUploads => _session.DisplayUploads;
// SpeedEma 现在在 _session.SpeedEma
```

#### 改动 2: 添加 Loaded 事件恢复轮询

```csharp
Loaded += async (_, __) =>
{
    try
    {
        // 恢复轮询状态：如果有活跃的上传任务，重新启动轮询
        if (_session.HasActiveUploads)
        {
            await RefreshUploadStatusesAsync(CancellationToken.None);
            if (!_statusTimer.IsEnabled)
                _statusTimer.Start();
        }
    }
    catch (Exception ex)
    {
        Logger.Warn($"Restore upload polling failed: {ex.Message}");
    }
};
```

#### 改动 3: 更新 Unloaded 事件

```csharp
Unloaded += (_, __) =>
{
    TaskResetNotifier.TasksReset -= OnTasksReset;
    // 停止计时器但不清除数据，以便下次加载时恢复
    if (_statusTimer.IsEnabled)
        _statusTimer.Stop();
};
```

#### 改动 4: 保存状态到 Session

```csharp
private async void ConfirmStart_Click(object sender, RoutedEventArgs e)
{
    // ...
    
    // 保存 PageId 到 session
    _session.PageId = pageId;
    
    // ...创建任务...
    
    // 标记有活跃任务
    _session.HasActiveUploads = true;
    
    // 初始化 EMA
    _session.SpeedEma[path] = 0.0;
}
```

#### 改动 5: 重构轮询逻辑

```csharp
// 添加独立的刷新方法供 Loaded 事件调用
private async Task RefreshUploadStatusesAsync(CancellationToken token)
{
    if (!_svc.IsReady)
        return;

    var statuses = await _svc.GetUploadStatusesAsync(token);
    
    // ...更新 UI...
    
    // 使用 session 的 SpeedEma
    _session.SpeedEma[s.FilePath] = ema;
    
    // 更新活跃状态标志
    _session.HasActiveUploads = DisplayUploads.Count > 0;
}

// 轮询 Tick 事件调用刷新方法
private async void UploadStatusTick(object? sender, EventArgs e)
{
    if (!_svc.IsReady)
        return;

    try
    {
        await RefreshUploadStatusesAsync(CancellationToken.None);
        
        // 如果没有任务了，停止轮询
        if (DisplayUploads.Count == 0 && _statusTimer.IsEnabled)
        {
            _statusTimer.Stop();
            _session.HasActiveUploads = false;
        }
    }
    catch (Exception ex)
    {
        Logger.Error("Polling upload statuses failed", ex);
    }
}
```

#### 改动 6: 更新 TasksReset 处理

```csharp
private void OnTasksReset()
{
    try
    {
        if (_statusTimer.IsEnabled)
            _statusTimer.Stop();

        _session.HasActiveUploads = false;

        Application.Current?.Dispatcher?.Invoke(() =>
        {
            try
            {
                DisplayUploads.Clear();
                SelectedUploadFiles.Clear();
                _session.SpeedEma.Clear();
                ModalHint.Text = "";
            }
            catch { }
        });
    }
    catch { }
}
```

---

## 修复效果

### 修复前
1. ❌ 切换页面后任务列表消失
2. ❌ 无法查看上传进度
3. ❌ 上传完成无提示
4. ❌ 用户体验差

### 修复后
1. ✅ 切换页面任务列表保持
2. ✅ 随时可以查看上传进度
3. ✅ 任务状态实时更新
4. ✅ 用户体验与下载页一致

---

## 测试验证

### 测试场景 1: 基本上传流程
1. 选择文件并开始上传
2. 观察任务列表显示正常
3. 等待上传完成
4. ✅ 验证：任务正常显示并更新

### 测试场景 2: 页面切换保持
1. 选择文件并开始上传
2. 切换到下载页面
3. 等待 5 秒
4. 切换回上传页面
5. ✅ 验证：任务列表仍然存在，进度继续更新

### 测试场景 3: 多次切换
1. 开始上传任务
2. 快速切换页面 5 次（上传→下载→工具箱→设置→上传）
3. ✅ 验证：任务列表保持，轮询正常

### 测试场景 4: 重置任务
1. 开始上传任务
2. 切换到设置页
3. 点击"应用设置并重置任务"
4. 切换回上传页
5. ✅ 验证：任务列表已清空

### 测试场景 5: 程序重启
1. 开始上传任务
2. 关闭程序（任务中断）
3. 重新启动程序
4. ✅ 验证：任务列表清空（符合预期，程序重启后后端任务不保留）

---

## 相关文件清单

### 新增文件
- `Services/UploadSession.cs` - 上传会话状态单例

### 修改文件
- `Views/UploadPage.xaml.cs` - 使用 Session，添加 Loaded/Unloaded 处理

### 未修改文件（参考）
- `Services/DownloadSession.cs` - 下载会话状态（参考实现）
- `Views/DownloadPage.xaml.cs` - 下载页面（参考实现）

---

## 注意事项

### 对现有功能的影响
- ✅ 不影响下载功能
- ✅ 不影响工具箱功能
- ✅ 不影响设置功能
- ✅ 仅增强上传功能的稳定性

### 代码兼容性
- ✅ 向后兼容（无破坏性改动）
- ✅ XAML 绑定无需修改
- ✅ Python 后端无需修改

### 性能影响
- ✅ 无负面性能影响
- ✅ 单例模式避免重复创建集合
- ✅ 轮询逻辑优化

---

## 后续建议

### 短期优化
1. 添加单元测试覆盖 Session 逻辑
2. 添加集成测试验证页面切换场景
3. 完善日志记录（Session 状态变化）

### 长期优化
1. 考虑将配置参数也保存到 Session
2. 实现任务持久化（程序重启后恢复）
3. 统一 DownloadSession 和 UploadSession 的设计

---

## 总结

此次修复通过引入 `UploadSession` 单例模式，成功解决了上传页面切换后任务列表消失的问题。修复方案参考了下载页面的成熟实现，确保了代码风格的一致性和稳定性。

**关键技术点**:
- 单例模式管理状态
- WPF 页面生命周期理解
- Loaded/Unloaded 事件处理
- ObservableCollection 生命周期管理

**修复日期**: 2026年2月12日
