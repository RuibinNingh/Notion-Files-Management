using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;

namespace Notion_Files_Management.Models
{
    /// <summary>
    /// Minimal base class for WPF binding.
    /// - Implements <see cref="INotifyPropertyChanged"/>
    /// - Provides <see cref="SetProperty"/> helper
    /// </summary>
    public abstract class ObservableObject : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler? PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string? name = null)
            => PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));

        protected bool SetProperty<T>(ref T field, T value, [CallerMemberName] string? name = null)
        {
            if (EqualityComparer<T>.Default.Equals(field, value))
                return false;

            field = value;
            OnPropertyChanged(name);
            return true;
        }
    }
}
