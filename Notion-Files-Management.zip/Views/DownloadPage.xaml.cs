﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Threading;
using Microsoft.Win32;
using Python.Runtime;

namespace Notion_Files_Management.Views
{
	// C# 端用来勾选的包装类
	public class FileSelectItem
	{
		public string? real_name
		{
			get; set;
		}
		public double size_mb
		{
			get; set;
		}
		public bool IsSelected { get; set; } = true;
		public dynamic? raw_dict
		{
			get; set;
		} // 存储 Python 返回的原始字典
	}

	// 对应文档中 get_download_statuses 的返回结构
	public class DownloadTaskStatus
	{
		public string? real_name
		{
			get; set;
		}
		public string? status
		{
			get; set;
		}
		public double progress
		{
			get; set;
		}
		public double downloaded_mb
		{
			get; set;
		}
		public double total_mb
		{
			get; set;
		}
		public double speed_mb_s
		{
			get; set;
		}
		public int ETA
		{
			get; set;
		}
		public string? error
		{
			get; set;
		}
	}

	public partial class DownloadPage : Page
	{
		private dynamic? _pyMain;
		private DispatcherTimer _statusTimer;

		public ObservableCollection<FileSelectItem> FileSelectionList { get; set; } = new();
		public ObservableCollection<DownloadTaskStatus> DisplayTasks { get; set; } = new();

		public DownloadPage()
		{
			InitializeComponent();
			FileListSelector.ItemsSource = FileSelectionList;
			DownloadTaskListView.ItemsSource = DisplayTasks;

			_statusTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
			_statusTimer.Tick += UpdateStatusLoop;

			InitBackend();
		}

		private string _currentNotionToken = "";

		private void InitBackend()
		{
			Task.Run(() =>
			{
				using (Py.GIL())
				{
					try
					{
						// ✅ 1) 确保读取到最新配置（你 Settings 保存到 AppData 的就是这里）
						ConfigManager.Load();
						string token = ConfigManager.Current?.NotionToken?.Trim() ?? "";

						if (string.IsNullOrEmpty(token))
						{
							Dispatcher.BeginInvoke(() =>
								MessageBox.Show("未检测到 Notion Token，请先到【设置】页保存 Token。"));
							return;
						}

						// ✅ 2) 设置 python 脚本路径
						dynamic sys = Py.Import("sys");
						string scriptsPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Scripts");
						sys.path.append(scriptsPath);

						// ✅ 3) 导入 main，并把 token 传进去
						dynamic mainMod = Py.Import("main");

						// 如果你希望 max_workers 可配，这里可以加第二个参数
						_pyMain = mainMod.Main(token);

						_currentNotionToken = token;
					}
					catch (Exception ex)
					{
						Dispatcher.BeginInvoke(() =>
							MessageBox.Show("初始化失败: " + ex.Message));
					}
				}
			});
		}

		private CancellationTokenSource? _getListCts;
		private int _getListReqId = 0; // 每次获取列表自增，防止旧任务回写UI


		// ========== 新增：打开下载对话框 ==========
		private void BtnOpenDownloadDialog_Click(object sender, RoutedEventArgs e)
		{
			ModalOverlay.Visibility = Visibility.Visible;
			ModalStep1.Visibility = Visibility.Visible;
			ModalStep2.Visibility = Visibility.Collapsed;
		}

		// --- 动作 1: 获取列表 (对应 get_download_list) ---
		private async void ConfirmId_Click(object sender, RoutedEventArgs e)
		{
			ConfigManager.Load();
			string latestToken = ConfigManager.Current?.NotionToken?.Trim() ?? "";
			if (string.IsNullOrEmpty(latestToken))
			{
				MessageBox.Show("Token 为空，请先到【设置】页保存 Token。");
				return;
			}

			if (_pyMain == null || latestToken != _currentNotionToken)
			{
				InitBackend();
				MessageBox.Show("检测到 Token 更新或后端未初始化，已重新初始化。请再点一次【获取列表】。");
				return;
			}

			string pidRaw = PageIdInput.Text.Trim();
			if (string.IsNullOrEmpty(pidRaw) || _pyMain == null)
				return;

			// 标准化 Notion ID：去空格、去掉 "-"
			string pid = pidRaw.Replace(" ", "");
			//string pid = pidRaw;
			// 取消上一次未完成的请求
			_getListCts?.Cancel();
			_getListCts = new CancellationTokenSource();
			var token = _getListCts.Token;

			int reqId = ++_getListReqId;
			BtnConfirmId.IsEnabled = false;

			try
			{
				var list = await Task.Run(() =>
				{
					token.ThrowIfCancellationRequested();

					using (Py.GIL())
					{
						dynamic pyList = _pyMain.get_download_list(pid);

						// ✅ 先取长度（能第一时间判断是不是 Python 返回空）
						int count = 0;
						try
						{
							count = (int)pyList.__len__();
						}
						catch { /* ignore */ }

						var result = new List<FileSelectItem>();
						foreach (var item in pyList)
						{
							token.ThrowIfCancellationRequested();

							// 如果 Python 返回结构不对，这里会抛异常，我们让它冒泡到外层 catch
							result.Add(new FileSelectItem
							{
								real_name = item["real_name"]?.ToString(),
								size_mb = (double)(item["size_mb"] ?? 0.0),

								// ⚠️你后面下载阶段要用字段重建 PyDict（别再传 raw_dict）
								raw_dict = null
							});
						}

						// 双保险：如果 __len__ 得到 0，但 foreach 也确实没有元素
						// 返回 result 即可
						return (result, count);
					}
				}, token);

				if (token.IsCancellationRequested || reqId != _getListReqId)
					return;

				// ✅ Python 返回空，直接提示（这一步能把“渲染 vs Py”彻底分清）
				if (list.Item1.Count == 0)
				{
					MessageBox.Show(
						$"Python 返回 0 个文件项（pyList.__len__() = {list.Item2}）。"
					);
				}

				FileSelectionList.Clear();
				foreach (var x in list.Item1)
					FileSelectionList.Add(x);

				ModalStep1.Visibility = Visibility.Collapsed;
				ModalStep2.Visibility = Visibility.Visible;
			}
			catch (OperationCanceledException)
			{
				// ignore
			}
			catch (Exception ex)
			{
				// ✅ 关键：把 Python/C# 的异常显式展示出来，否则你只看到“啥也没有”
				MessageBox.Show("获取列表失败: " + ex.Message);
			}
			finally
			{
				if (reqId == _getListReqId)
					BtnConfirmId.IsEnabled = true;
			}
		}




		// --- 动作 2: 提交下载 (对应 download_notion_files) ---
		private async void SubmitDownload_Click(object sender, RoutedEventArgs e)
		{
			if (string.IsNullOrEmpty(SavePathDisplay.Text) || _pyMain == null)
				return;

			// 过滤出用户勾选的项目
			var selected = FileSelectionList.Where(x => x.IsSelected).ToList();
			if (selected.Count == 0)
				return;

			string saveDir = SavePathDisplay.Text;

			await Task.Run(() => {
				using (Py.GIL())
				{
					// 构建符合文档要求的 download_list (Python 字典列表)
					PyList pyListToDownload = new PyList();
					foreach (var s in selected)
					{
						pyListToDownload.Append(s.raw_dict);
					}

					// 调用文档中的 download_notion_files
					_pyMain.download_notion_files(pyListToDownload, saveDir);
				}
			});

			ModalOverlay.Visibility = Visibility.Collapsed;
			if (!_statusTimer.IsEnabled)
				_statusTimer.Start();
		}

		// --- 动作 3: 状态更新轮询 (对应 get_download_statuses) ---
		private async void UpdateStatusLoop(object? sender, EventArgs e)
		{
			if (_pyMain == null)
				return;

			try
			{
				var statuses = await Task.Run(() =>
				{
					using (Py.GIL())
					{
						var pyStatuses = _pyMain.get_download_statuses();

						var result = new List<DownloadTaskStatus>();
						foreach (var s in pyStatuses)
						{
							result.Add(new DownloadTaskStatus
							{
								real_name = s["real_name"]?.ToString(),
								status = s["status"]?.ToString(),
								progress = (double)(s["progress"] ?? 0.0),
								downloaded_mb = (double)(s["downloaded_mb"] ?? 0.0),
								total_mb = (double)(s["total_mb"] ?? 0.0),
								speed_mb_s = (double)(s["speed_mb_s"] ?? 0.0),
								ETA = (int)(s["ETA"] ?? 0),
								error = s["error"]?.ToString()
							});
						}
						return result;
					}
				});

				// UI 线程更新集合
				DisplayTasks.Clear();
				foreach (var x in statuses)
					DisplayTasks.Add(x);
			}
			catch
			{
				// 这里保持安静可以
			}
		}


		private void SelectFolder_Click(object sender, RoutedEventArgs e)
		{
			var dialog = new OpenFolderDialog();
			if (dialog.ShowDialog() == true)
				SavePathDisplay.Text = dialog.FolderName;
		}

		private void SelectAll_Click(object sender, RoutedEventArgs e)
		{
			foreach (var i in FileSelectionList)
				i.IsSelected = true;
			FileListSelector.Items.Refresh();
		}

		private void InvertSelect_Click(object sender, RoutedEventArgs e)
		{
			foreach (var i in FileSelectionList)
				i.IsSelected = !i.IsSelected;
			FileListSelector.Items.Refresh();
		}

		// ========== 新增：返回 Step1 ==========
		private void BackToStep1_Click(object sender, RoutedEventArgs e)
		{
			ModalStep2.Visibility = Visibility.Collapsed;
			ModalStep1.Visibility = Visibility.Visible;
		}

		private void CloseModal_Click(object sender, RoutedEventArgs e)
		{
			// 取消获取列表（只能做到“取消回写UI/取消等待”，不能强杀Python内部请求）
			_getListCts?.Cancel();

			// 立刻恢复按钮，避免下次打开还是灰
			BtnConfirmId.IsEnabled = true;

			ModalOverlay.Visibility = Visibility.Collapsed;
			ModalStep1.Visibility = Visibility.Collapsed;
			ModalStep2.Visibility = Visibility.Collapsed;
		}

	}
}